package application.ViewModels;

public abstract class ViewModel {
	
	public abstract void load();
	
}
